Comunicados FullStack con JS

- Realiza filtro por marca y ejecutivos
- Muestra las ciudades con base al filtro
- En la siguiente versión se agregará un nuevo arreglo que devolverá el arreglo final de las ciudades seleccionadas
